# @casperid/react

The official React SDK for integrating CasperID — the privacy-first, decentralized identity layer for the open web.

## Hosted Authorization

Passkeys registered for `casperid.com` must be used from the CasperID account domain. Affiliate applications should start the hosted flow instead of rendering the legacy authentication modal:

```tsx
import { authorizeWithCasperID } from '@casperid/react';

const result = await authorizeWithCasperID({
  clientId: 'app_your_client_id',
  redirectUri: `${window.location.origin}/auth/callback`,
  accountUrl: 'https://account.casperid.com',
  mode: 'auto',
});
```

`auto` opens a popup on desktop and redirects the full page on mobile. On the callback route, call `consumeHostedAuthorizationCallback()`. Send its `code`, `codeVerifier`, and `redirectUri` to your backend, which exchanges them at `POST /api/oauth/token` using the app secret. Never expose the app secret in frontend code.

## Why CasperID?

CasperID provides a "Sign in with Google" style experience but with the security and ownership of Web3.

- **Biometric Security:** Native Passkey (WebAuthn) support for passwordless, secure logins.
- **Privacy by Design:** Selective disclosure via Zero-Knowledge Proofs (ZKP). Only share what you need (e.g., "Over 18") without revealing raw data.
- **User Ownership:** Identities (DIDs) are owned by users on the Casper blockchain, not by a central authority.
- **Verification Tiers:** Securely handle everything from simple email verification (L1) to full KYC document verification (L3).

## Installation

```bash
npm install @casperid/react
```

## Quick Start

```tsx
import { CasperIDProvider, CasperIDModal } from '@casperid/react';
import '@casperid/react/style.css';

function App() {
  const [isOpen, setIsOpen] = useState(false);

  const handleSuccess = (sessionToken, data) => {
    console.log('Verified!', sessionToken, data?.businessToken);
    setIsOpen(false);
  };

  return (
    <div>
      <button onClick={() => setIsOpen(true)}>Verify with CasperID</button>
      
      <CasperIDModal 
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onSuccess={handleSuccess}
        apiKey="your_api_key_here"
        requiredTier="layer_2" // Liveness verification
      />
    </div>
  );
}
```

## Handling Success

The `onSuccess` callback provides the `sessionToken` as the first argument and an optional `data` object containing the `businessToken` as the second argument.

```tsx
const handleSuccess = (sessionToken, { businessToken } = {}) => {
  // 1. Send businessToken to your server for verification
  // 2. Decode it to get user identity
};
```

### Understanding User Identity

When you decode the `businessToken` or call the `/verify-token` endpoint, you will receive:

- **`humanId`**: This is the unique, user-friendly handle (e.g., `alice.casper`). **This should be prioritized for your UI.**
- **`name`**: The user's verified full name (or `null` if not shared).
- **`wallet`**: The Casper wallet address. In early registration stages, this may be `pending_wallet` until the user finishes minting. The SDK automatically refreshes the token once minting is complete.

## Documentation

For full documentation, visit [casperid.com/business/docs](http://casperid.com/business/docs).

## License

MIT
